#include "zf_common_headfile.h"


extern int error;
extern int error_last;
extern float p;
extern float d;
extern int sum_l;
extern int sum_r;
extern int com;


extern uint8 blue;
extern void dianci_init();
extern void dianci_read();
extern void steer_control();
extern void ad_set();
