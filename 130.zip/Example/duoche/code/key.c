#include "zf_common_headfile.h"
#include "heaaaad.h"

void key_init()
{
    gpio_init(B0, GPI, GPIO_LOW, GPI_PULL_UP);
    gpio_init(B12, GPI, GPIO_LOW, GPI_PULL_UP);
    gpio_init(D8, GPI, GPIO_LOW, GPI_PULL_UP);
    gpio_init(A8, GPI, GPIO_LOW, GPI_PULL_UP);
}

void key_check()
{
    if(!gpio_get_level(B0))
          {
              system_delay_ms(50);
              if(!gpio_get_level(B0))
              {
              //����
              }
          }
    if(!gpio_get_level(B12))
              {
                  system_delay_ms(50);
                  if(!gpio_get_level(B12))
                  {
                  //����
                  }
              }
    if(!gpio_get_level(D8))
              {
                  system_delay_ms(50);
                  if(!gpio_get_level(D8))
                  {
                  //����
                  }
              }
    if(!gpio_get_level(A8))
              {
                  system_delay_ms(50);
                  if(!gpio_get_level(A8))
                  {
                  //����
                  }
              }
}
