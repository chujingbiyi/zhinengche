#include "zf_common_headfile.h"
#include "heaaaad.h"

extern PID PID1,PID2;

 void PID_Init(pPID PID,int16_t kp, int16_t ki, int16_t kd,int16_t speed)
 {
     PID->p = kp;    PID->i = ki;    PID->d = kd;
     PID->target_speed=speed;
     PID->err_value = 0;
     PID->pre_err_value = 0;
     PID->sum_err_value = 0;
 }


 int16_t PIDINC;

 int16_t tarspeed=50;
 int PID_Process(pPID PID, int16_t current_speed)
 {
     PID->err_value = PID->target_speed- current_speed ;//��ֵ
     PIDINC =  (PID->p * (PID->err_value - PID->pre_err_value                  )) + //P��  Kp[e(k)-e(k-1)]
               (PID->i *  PID->err_value                                    ) +//I��  Kie(k)
               (PID->d * (PID->err_value - 2*PID->pre_err_value+PID->pre_err_value2));  //D��  Kd[e(k)-2e(k-1)+e(k-2)
     PID->pre_err_value2 = PID->pre_err_value;
     PID->pre_err_value = PID->err_value;

     return PIDINC;
 }

int  limit_duty(int duty)
 {
     int max_duty=10000;             //�϶�45000
     if(duty>max_duty) duty=+max_duty;
     if(duty<-max_duty) duty=-max_duty;
     return duty;
 }
 int PID_duty1=0;
 int PID_duty2=0;
int16_t motor_dir_l=1;
int16_t motor_dir_r=1;

 void launch( )
 {
     PID_duty1 += PID_Process(&PID1, cur_speed1);
     PID_duty1=limit_duty(PID_duty1);
     if(PID_duty1 >= 0)
     {
         motor_dir_l=1;
         motor_control(TIM4_PWM_CH4_D15,motor_dir_l,PID_duty1);
     }
     else
     {
         motor_dir_l=0;
         motor_control(TIM4_PWM_CH4_D15,motor_dir_l,-PID_duty1);
     }
 }
 void launch2( )
  {
     PID_duty2 += PID_Process(&PID2, cur_speed2);
      PID_duty2=limit_duty(PID_duty2);
      if(PID_duty2 >= 0)
      {
          motor_dir_r=1;
          motor_control(TIM4_PWM_CH1_D12,motor_dir_r,PID_duty2);
      }
      else
      {
          motor_dir_r=0;
          motor_control(TIM4_PWM_CH1_D12,motor_dir_r,-PID_duty2);
      }
  }


//int tar_dis=300;
//int dis=0;
//int dis_error=0;
//int dis_error_last=0;
//float p_sp=0.07;
//float d_sp=0.07;
// void speed_control()
// {
//     ultrasound_read();
//     dis=ranging_counter;
//
//     dis_error_last=dis_error;
//     dis_error=dis-tar_dis;
//     PID1.target_speed=PID2.target_speed=30+p_sp*dis_error_last+p_sp*dis_error;
//     if(PID1.target_speed<0) PID1.target_speed=PID2.target_speed=0;
//     if(PID1.target_speed>60) PID1.target_speed=PID2.target_speed=60;
//     if(dis>3000) PID1.target_speed=PID2.target_speed=30;
// }

 int16 cur_speed1,cur_speed2;
 PID PID1,PID2;
 int kp=190,ki=20,kd=10;
 int x=0;
 int pidflag=0;
 void pid()
 {
     cur_speed1 =encoder_get_count(TIM1_ENCOEDER);
     cur_speed2 =-encoder_get_count(TIM9_ENCOEDER);
//    {//������λ��
//              uart_write_byte(UART_2 , 0x03);
//              uart_write_byte(UART_2 , 0xFC);
//              uart_write_byte(UART_2 , (cur_speed1)&0xff);
//              uart_write_byte(UART_2 , (cur_speed1)>>8);
//              uart_write_byte(UART_2 , (cur_speed2)&0xff);
//              uart_write_byte(UART_2 , (cur_speed2)>>8);
//              uart_write_byte(UART_2 , 0xFC);
//              uart_write_byte(UART_2 , 0x03);
//              }
     encoder_clean_count(TIM1_ENCOEDER);
     encoder_clean_count(TIM9_ENCOEDER);
     launch();
     launch2();
 }


 void pid_set()
 {
     {

         if(!gpio_get_level(B0))
             {
                 system_delay_ms(200);
                 if(!gpio_get_level(B0))
                 {
                     if(x==0) {PID1.p--;PID2.p--; }
                     else if(x==1) {PID1.i--;PID2.i--;}
                     else if(x==2) {PID1.d--;PID2.d--;}
                     else if(x==3) {PID1.target_speed-=10;PID2.target_speed-=10;}
                 }
             }
       if(!gpio_get_level(B12))
                 {
                     system_delay_ms(200);
                     if(!gpio_get_level(B12))
                     {
                         if(x==0) {PID1.p++;PID2.p++; }
                         else if(x==1) {PID1.i++;PID2.i++;}
                         else if(x==2) {PID1.d++;PID2.d++;}
                         else if(x==3) {PID1.target_speed+=10;PID2.target_speed+=10;}
                     }
                 }
       if(!gpio_get_level(D8))
                 {
                     system_delay_ms(200);
                     if(!gpio_get_level(D8))
                     {
                         x++;
                         if(x==4) x=0;
                     }
                 }
       if(!gpio_get_level(A8))
                 {
                   system_delay_ms(200);
                 if(!gpio_get_level(A8))
                 {
                 }
                 }
         oled_show_string(70,x,"<");
         char txt_tmp[20];
        sprintf(txt_tmp,"p:%d          ",PID2.p);
        oled_show_string(0, 0,txt_tmp);
        sprintf(txt_tmp,"i:%d          ",PID2.i);
        oled_show_string(0, 1,txt_tmp);
        sprintf(txt_tmp,"d:%d          ",PID2.d);
        oled_show_string(0, 2,txt_tmp);
        sprintf(txt_tmp,"target_speed:%d          ",PID2.target_speed);
        oled_show_string(0, 3,txt_tmp);


     }
 }
