#include "zf_common_headfile.h"


extern void key_init();
extern void key_check();
