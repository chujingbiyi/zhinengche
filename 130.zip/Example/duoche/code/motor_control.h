#include "zf_common_headfile.h"

#define motor_l         TIM4_PWM_CH1_D12                //������������ΪD12
extern uint32 motor_l_dir;
extern uint32 motor_r_dir;
#define motor_r         TIM4_PWM_CH4_D15




extern void motor_init();
extern void motor_control(uint32 motor,uint32 dir,uint duty);
