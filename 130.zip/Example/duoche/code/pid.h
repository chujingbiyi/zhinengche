#include "zf_common_headfile.h"

extern int16_t PIDINC;
 typedef struct PID
 {
     int p, i, d;

     int16_t err_value,pre_err_value,pre_err_value2, sum_err_value,
     target_speed;
 }*pPID,PID;
 extern int x;
 extern PID PID1,PID2;
 extern int16 cur_speed1;
 extern int16 cur_speed2;
 extern int16_t tarspeed;


 extern int kp;
 extern int ki;
 extern int kd;
 extern uint16_t dat[8];

extern  int16_t motor_dir_l;
extern  int16_t motor_dir_r;

extern int dis;

extern  void PID_Init(pPID PID,int16_t kp, int16_t ki, int16_t kd,int16_t speed);
extern  int PID_Process(pPID PID, int16_t current_speed);
extern void launch();
extern void launch2();
extern void pid();
extern void pid_set();
