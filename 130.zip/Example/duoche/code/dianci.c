#include "zf_common_headfile.h"
#include "heaaaad.h"


uint16_t dat[8]={0,0,0,0,0,0,0,0};

int duty=1000;

int qishiflag=0;
int jieshuflag=0;
int fffll=0;
float SpeedBase = 80;
float SpeedMax = 93;
float SpeedMin = 20;
void dianci_init()
{
        adc_init(ADC_IN12_C2);              //C2 C3 C4 C5 A7 B1 C0
        adc_init(ADC_IN13_C3);
        adc_init(ADC_IN14_C4);
        adc_init(ADC_IN15_C5);
        adc_init(ADC_IN7_A7);
        adc_init(ADC_IN9_B1);
        adc_init(ADC_IN10_C0);
        pwm_init(TIM2_PWM_CH1_A15,50,1000);     //�������
}


int huandaoflag=0;      //������־λ
int forkflag=0;         //������־λ
int hullflag=0;         //ͣ������־λ   ��Ϊ0
int huanshuflag=0;      //������־λ

int error=0;
int error_last=0;
int steer_duty_m=73;    //����޷����


float p=0.08;//0.10
float d=0.45;//0.02
int num=0;
float angle_z=0;
float angle_z0=0;
float angle_z2=0;

 uint16 a=3,b=1;

#define average_speed 80
int speed_fature=average_speed;
int speed_low=30;



int huandao_turn=0;
int turn_flag=0;
int yanshi=0;

void huandao_check2()
{
    if (dat[3]>190&&huandaoflag==0&&(dat[1]>120||dat[5]>120))
    {
        gpio_init(C13, GPO, 1, GPO_PUSH_PULL);
        if(dat[6]-dat[7]>0)
        {
            turn_flag=1;  //��
        }
        if(dat[6]-dat[7]<0)
        {
            turn_flag=2;  //��
        }
        huandaoflag=1;                              //100 2700
//        }
    }
    if(huandaoflag==1)
    {
        if(turn_flag==1)
        {
            a=1;
            b=6;
            dat[1]*=0.4;
            dat[2]*=0.4;
        }
        if(turn_flag==2)
        {
            a=1;
            b=6;
            dat[4]*=0.6;
            dat[5]*=0.8;
            if(dat[6]>=65){
                turn_flag=3;
            }

        }
        if(turn_flag==3){
            dat[4]*=0.2;
            dat[5]*=0.2;
        }
        icm20602_get_gyro ();
        angle_z-=icm_gyro_z/16.4*0.008;
        if(angle_z>30||angle_z<-30)
        {
            huandaoflag=2;
        }

    }
    if(huandaoflag==2)
   {
        a=3;
        b=1;
        icm20602_get_gyro ();
        angle_z2-=icm_gyro_z/16.4*0.008;
        if(angle_z2>300||angle_z2<-300)
        {
            huandaoflag=3;
            gpio_init(C13, GPO, 0, GPO_PUSH_PULL);
        }
    }
    if(huandaoflag==3)
    {
        icm20602_get_gyro ();
        angle_z0-=1.0*icm_gyro_z/16.4*0.008;
        if(angle_z2>=0){
            dat[1]=dat[1]*0.4;//  75------0.4
            dat[2]=dat[2]*0.4;
        }
        if(angle_z2<0){
            dat[4]=dat[4]*0.4;
            dat[5]=dat[5]*0.4;
        }
        if(angle_z0>=110)            //75-----70
        {
            huandaoflag=4;
            gpio_init(C13, GPO, 1, GPO_PUSH_PULL);
        }
        if(angle_z0<=-110)             //110
        {
            huandaoflag=4;
            gpio_init(C13, GPO, 1, GPO_PUSH_PULL);
        }
    }
    if(huandaoflag==4)
    {
        angle_z2=0;
        angle_z=0;
        angle_z0=0;
        a=1;
        b=0;
        huandaoflag=5;
    }
    if(huandaoflag==5)
    {
        yanshi += cur_speed1;
        if(yanshi>=8000){
        huandaoflag=0;
        a=3;
        b=1;
        yanshi=0;
        gpio_init(C13, GPO, 0, GPO_PUSH_PULL);
        }
    }
}



void huandao_check()
{
    if (dat[3]>170&&(dat[1]>80||dat[5]>80)&&huandaoflag==0&&forkflag==0)
       {
           a=1;
           b=9;
           huandaoflag=1;
           angle_z=0;

           if(dat[7]>dat[6]) huandao_turn=0;
           else {huandao_turn=1;}
       }
      if(huandaoflag==1)     //���������ǻ���
      {
            if(huandao_turn==0)     //��ת
            {
                gpio_init(C13, GPO, 1, GPO_PUSH_PULL);
          dat[3]*=0.6;
          dat[4]*=0.4;
          dat[5]*=0.4;
            }
            else
            {
          dat[3]*=0.8;
          dat[1]*=0.4;
          dat[2]*=0.4;
            }
          icm20602_get_gyro ();
          angle_z+=icm_gyro_z/16.4*0.005;
          if(angle_z>40||angle_z<-40)
          {
              huandaoflag=2;
              gpio_init(C13, GPO, 0, GPO_PUSH_PULL);
          }
      }
    else if(huandaoflag==2)
      {
          icm20602_get_gyro ();
          angle_z+=icm_gyro_z/16.4*0.005;
          if(angle_z>200||angle_z<-200)
          {
              huandaoflag=3;
          }
      }
    else if(huandaoflag==3)
       {
            icm20602_get_gyro ();
            angle_z+=icm_gyro_z/16.4*0.005;
           if(angle_z<0) {
               dat[1]*=0.4;dat[2]*=0.4;
           }
           else {
               dat[4]*=0.4;dat[5]*=0.4;
           }
           if(angle_z>250||angle_z<-250)//280
           {
           huandaoflag=4;
           }
       }
    else if(huandaoflag==4)
    {
        if(angle_z<0) {
                       dat[4]*=0.3f;dat[5]*=0.3;
                   }
                   else {
                       dat[2]*=0.3f;dat[1]*=0.3;
                   }
        if(dat[3]>95)
            {

            huandaoflag=5;
            yanshi=0;
            }
    }
    else if(huandaoflag==5)
    {
        yanshi+=cur_speed1;
        if(yanshi > 500 && yanshi < 6000)
        {
            gpio_init(C13, GPO, 1, GPO_PUSH_PULL);
            if(angle_z<0) {
               if(dat[5] >50)
                   dat[4]*=0.f;
               dat[5]*=0.7;
               if(dat[1] < dat[5])
                   dat[5]*=0.5;
           }
           else {
               if(dat[1] >50)
                   dat[2]*=0.f;
               dat[1]*=0.7;
               if(dat[1] > dat[5])
                   dat[1]*=0.5;
           }
        }

        if(yanshi>6000) {
            gpio_init(C13, GPO, 0, GPO_PUSH_PULL);
            huandaoflag=0;
        a=3;
        b=1;}
    }
}




int stop_flag=0;
void stop()
{
    int i=0,j=0;
    for(i=1;i<8;i++)
    {
        if(dat[i]<=3) j++;
    }
    if(j>4) stop_flag=1;
    if(stop_flag==1){
        PID1.target_speed=PID2.target_speed=0;
    }
}


void fork_check()
{
    if(forkflag==0&&huandaoflag==0&&
            dat[1]<80&& dat[5]<80&&             //����
            dat[3]>40&&dat[3]<90&&              //�м���
            dat[2]<20&&dat[4]<20&&              //�����
            dat[6]>40&&dat[7]>40&&dat[6]<70&&dat[7]<70      //б���
          )
    {
        speed_fature=10;
        gpio_init(C13, GPO, 1, GPO_PUSH_PULL);
        forkflag=1;
        angle_z=0;
    }
    if(forkflag==1)
    {
        if(hullflag==0)
        {
        dat[1]=0;
        dat[2]=0;
        dat[4]+=80;
        dat[5]+=80;
        }
        else
        {
        dat[1]+=80;
        dat[2]+=80;
        dat[4]=0;
        dat[5]=0;
        }
        icm20602_get_gyro ();
        angle_z+=1.0*icm_gyro_z/16.4*0.008;
        if(angle_z>30||angle_z<-30)
        {
        forkflag=2;
        gpio_init(C13, GPO,0, GPO_PUSH_PULL);
        speed_fature=speed_low;
        }
    }
    if((blue=='2'||hullflag==1)&&forkflag==2)
//    if(forkflag==2)
        {
        forkflag=3;
        speed_fature=70;
        }
    if(forkflag==3)
    {
        dat[1]=dat[1]*2.5;
        dat[2]=dat[2]*2.5;
        dat[3]=dat[3]*2.5;
        dat[4]=dat[4]*2.5;
        dat[5]=dat[5]*2.5;
        if(dat[6]>=100||dat[7]>=100) forkflag=4;
    }
    if(forkflag==4)
    {
        angle_z=0;
        forkflag=0;
        hullflag++;
        speed_fature=average_speed;
        gpio_init(C13, GPO, 0, GPO_PUSH_PULL);
    }
}



uint16_t adc_check(ADC_CH_enum adc_in,ADC_RES_enum adc_bit,char adc_num)//��ֵƽ���˲�+��һ������
{
    uint16_t i,j,k; uint16_t temp,sum=0;
    //��ֵƽ���˲�
    for(int x=0;x<10;x++)
    {
    i=adc_convert(adc_in,adc_bit);
    j=adc_convert(adc_in,adc_bit);
    k=adc_convert(adc_in,adc_bit);
    if(i>=j)
    {
        if(k>=i) temp=i;
        else if(k<=j) temp=j;
        else temp=k;
    }
    else
    {
        if(k>=j) temp=j;
        else if(k<=i) temp=i;
        else temp=k;
    }
    sum+=temp;
    }
    sum/=10;
    //��һ������
    if(adc_num==1||adc_num==3||adc_num==5)
        sum=100.0*(sum-0)/100;
    else if(adc_num==2||adc_num==4)
        sum=100.0*(sum-0)/80;
    else if(adc_num==6||adc_num==7)
        sum=200.0*(sum-0)/200;
    return sum;
}



void ad_get()
{
//           dat[1]=adc_check(ADC_IN12_C2, ADC_8BIT,1);
//           dat[2]=adc_check(ADC_IN13_C3, ADC_8BIT,2);
//           dat[3]=adc_check(ADC_IN14_C4, ADC_8BIT,3);
//           dat[4]=adc_check(ADC_IN15_C5, ADC_8BIT,4);
//           dat[5]=adc_check(ADC_IN7_A7, ADC_8BIT,5);
//           dat[6]=adc_check(ADC_IN9_B1, ADC_8BIT,6);
//           dat[7]=adc_check(ADC_IN10_C0, ADC_8BIT,7);

    dat[1]=adc_convert(ADC_IN12_C2, ADC_8BIT);
    dat[2]=adc_convert(ADC_IN13_C3, ADC_8BIT);
    dat[3]=adc_convert(ADC_IN14_C4, ADC_8BIT);
    dat[4]=adc_convert(ADC_IN15_C5, ADC_8BIT);
    dat[5]=adc_convert(ADC_IN7_A7, ADC_8BIT);
    dat[6]=adc_convert(ADC_IN9_B1, ADC_8BIT);
    dat[7]=adc_convert(ADC_IN10_C0, ADC_8BIT);
       {//������λ��
//                     uart_write_byte(UART_7 , 0x03);
//                     uart_write_byte(UART_7 , 0xFC);
//                     uart_write_byte(UART_7 , (dat[1])&0xff);
//                     uart_write_byte(UART_7 , (dat[1])>>8);
//                     uart_write_byte(UART_7 , (dat[2])&0xff);
//                    uart_write_byte(UART_7 , (dat[2])>>8);
//                    uart_write_byte(UART_7 , (dat[3])&0xff);
//                    uart_write_byte(UART_7 , (dat[3])>>8);
//                    uart_write_byte(UART_7 , (dat[4])&0xff);
//                    uart_write_byte(UART_7 , (dat[4])>>8);
//                    uart_write_byte(UART_7 , (dat[5])&0xff);
//                    uart_write_byte(UART_7 , (dat[5])>>8);
//                    uart_write_byte(UART_7 , (dat[6])&0xff);
//                    uart_write_byte(UART_7 , (dat[6])>>8);
//                    uart_write_byte(UART_7 , (dat[7])&0xff);
//                    uart_write_byte(UART_7 , (dat[7])>>8);
//                     uart_write_byte(UART_7 , 0xFC);
//                     uart_write_byte(UART_7 , 0x03);
        }
}



int tar_dis=400;        //��������������
int dis=0;
int dis_error=0;
int dis_error_last=0;
float p_sp=0.04;
float d_sp=0.04;


int compensate;

int waitflag=1;
int buchang=0;
int xxx=0;
int yyy=0;
void steer_control()
{
    if(blue=='4'&&fffll==0)             //�೵�������
    {
        PID1.target_speed=PID2.target_speed=average_speed;
        qishiflag=1;
        fffll=1;
    }
    if(qishiflag==1)
    {
    if((!gpio_get_level(D10))&&hullflag>=2)
    {
//      jieshuflag=1;
        yyy=1;
    }
    if(yyy)
        {
            xxx+=cur_speed1;
            if(xxx>1500)
                jieshuflag = 1;
        }
    if(jieshuflag==1)
    {
//        PID1.target_speed=PID2.target_speed=40;
//        xxx+=cur_speed1;
          PID1.target_speed=PID2.target_speed=0;
    }
    else
    {
//    PID1.target_speed=PID2.target_speed=average_speed;
    ad_get();   //��ȡ���ֵ
    fork_check();
    huandao_check2();

    error_last=error;
    error=650*(a*(dat[1]-dat[5])+b*(dat[2]-dat[4]))/(a*(dat[1]+dat[5])+b*(dat[2]+dat[4]));
    duty=1.0*p*error+1.0*d*(error-error_last)+1000;     //���pd 1000Ϊ��ֵ

    //��������㷨
    if(huandaoflag==1)
     compensate=2*600.0/(dat[1]+dat[3]+dat[5])*600.0/(dat[1]+dat[3]+dat[5])*600.0/(dat[1]+dat[3]+dat[5]);
    else
     compensate = 2*200.0*200/(dat[1]+dat[3]+dat[5])/(dat[1]+dat[3]+dat[5])*200*200/(dat[1]+dat[3]+dat[5])/(dat[1]+dat[3]+dat[5]);
    if(duty>1000) duty+=compensate;
    else duty-=compensate;


   //�೵�ٶȻ�
    if(forkflag==0)
    {
    ultrasound_read();
    dis=ranging_counter;
    if(dis<2000)
    {
    if(dis < 100)
    {
        speed_fature = SpeedMin;
    }
    if(dis <= tar_dis)
    {
        //[100,400] -->[20,80]
        speed_fature = (SpeedBase - SpeedMin) / (tar_dis - 100 ) * (dis - 100) + SpeedMin;
    }
    else if(dis <= 1000) {
        //[400,1000+] -->[80,88]
        speed_fature = (SpeedMax - SpeedBase) / (1000-tar_dis) * (dis - tar_dis) + SpeedBase;
    }
    else {
        speed_fature = SpeedMax;
    }

    if(speed_fature<SpeedMin) speed_fature=SpeedMin;
    if(speed_fature>SpeedMax) speed_fature=SpeedMax;
    }
    else
        speed_fature=SpeedBase;
    }






    if(hullflag==1&&waitflag==1)
    {
        if(dis<=tar_dis)   {wireless_ch573_send_buff("7", (1)); waitflag=2;}     //������
    }
    else if(hullflag==2&&waitflag==2)
    {
        if(dis<=tar_dis)   {wireless_ch573_send_buff("9", (1)); }
    }
//    if(blue=='3') yyy=1;
   //�����㷨
    if(forkflag!=1)
      {
          if(error>0) {PID1.target_speed=speed_fature-0.135*error; PID2.target_speed=speed_fature; }
          else {PID2.target_speed=speed_fature+0.135*error; PID1.target_speed=speed_fature; }
//          stop();
          //�ٶ��޷�
          if(PID1.target_speed<30) PID1.target_speed=30;
          if(PID2.target_speed<30) PID2.target_speed=30;
      }
    else
      {
        if(hullflag==0) {PID1.target_speed=average_speed; PID2.target_speed=average_speed-80;  duty=900;}
         else {PID2.target_speed=average_speed; PID1.target_speed=average_speed-80; duty=1100;}
      }

    //����޷�
    if(duty>1000+steer_duty_m)   duty=1000+steer_duty_m;
    if(duty<1000-steer_duty_m)   duty=1000-steer_duty_m;
    pwm_set_duty(TIM2_PWM_CH1_A15,duty);
//    char tt[20];
//    sprintf(tt,"s:%d  ",speed_fature);
//    wireless_ch573_send_buff (tt, 5);
    }
    }
}



int num_=0;
void ad_set()       //pd����
{
    oled_show_uint16(0, 0,  dat[1]);
    oled_show_uint16(0, 1,  dat[2]);
    oled_show_uint16(0, 2,  dat[3]);
    oled_show_uint16(0, 3,  dat[4]);
    oled_show_uint16(0, 4,  dat[5]);
    oled_show_uint16(0, 5,  dat[6]);
    oled_show_uint16(0, 6,  dat[7]);
          if(!gpio_get_level(B0))
                {
                    system_delay_ms(200);
                    if(!gpio_get_level(B0))
                    {
                        if(buchang==0)
                            buchang=1;
                        else buchang=0;
                    }
                }
          if(!gpio_get_level(B12))
                    {
                        system_delay_ms(200);
                        if(!gpio_get_level(B12))
                        {
                            num_++;
                            if(num_>1) num_=0;
                        }
                        oled_clear(0);
                    }
          if(!gpio_get_level(D8))
                    {
                        system_delay_ms(200);
                        if(!gpio_get_level(D8))
                        {
                            if(num_==0) p-=0.01;
                            if(num_==1) d-=0.01;
                            if(num_==2)
                            {
                                PID1.target_speed-=5;
                                PID2.target_speed-=5;
                            }
                        }
                        oled_clear(0);
                    }
          if(!gpio_get_level(A8))
                    {
                      system_delay_ms(200);
                        if(!gpio_get_level(A8))
                        {
                            if(num_==0) p+=0.01;
                            if(num_==1) d+=0.01;
                            if(num_==2)
                                {
                                    PID1.target_speed+=5;
                                    PID2.target_speed+=5;
                                }
                        }
                        oled_clear(0);
                        }
//
          char txt_tmp[20];
//          oled_show_string(120,num_,"<");
          sprintf(txt_tmp,"speed1:%d          ",cur_speed1);
          oled_show_string(40, 0,txt_tmp);

          sprintf(txt_tmp,"speed2:%d          ",cur_speed2);
          oled_show_string(40, 1,txt_tmp);
          sprintf(txt_tmp,"dis:%d          ",dis);
          oled_show_string(40, 2,txt_tmp);
          sprintf(txt_tmp,"jieshuflag:%d          ",jieshuflag);
          oled_show_string(40, 3,txt_tmp);
          sprintf(txt_tmp,"duty:%d          ",duty);
           oled_show_string(40, 4,txt_tmp);
           sprintf(txt_tmp,"speed_fature:%d          ",speed_fature);
          oled_show_string(40, 5,txt_tmp);
//          sprintf(txt_tmp,"sd:%.3f          ",d);
//          oled_show_string(40, 1,txt_tmp);
//          sprintf(txt_tmp,"cur_speed1:%d          ",cur_speed1);
//          oled_show_string(40, 2,txt_tmp);
//          sprintf(txt_tmp,"cur_speed2:%d          ",cur_speed2);
//          oled_show_string(40, 3,txt_tmp);
//          sprintf(txt_tmp,"a:%d          ",a);
//          oled_show_string(40, 4,txt_tmp);
//          sprintf(txt_tmp,"b:%d          ",b);
//          oled_show_string(40, 5,txt_tmp);
//          sprintf(txt_tmp,"duty:%d          ",duty);
//          oled_show_string(40, 6,txt_tmp);
//          sprintf(txt_tmp,"angle_z:%.3f  ",angle_z);
//          oled_show_string(40, 7,txt_tmp);
//            oled_show_int8(40, 0, blue);
//            oled_show_int16(40, 1, dis);
//            oled_show_int16(40,2,speed_fature);
}
